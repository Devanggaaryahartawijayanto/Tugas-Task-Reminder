package com.example.tugastaskreminder

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ReminderActivity : AppCompatActivity() {

    private lateinit var reminderTitle: TextView
    private lateinit var reminderDate: TextView
    private lateinit var reminderTime: TextView
    private lateinit var reminderRepeat: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminder)

        // Inisialisasi TextView
        reminderTitle = findViewById(R.id.reminder_title)
        reminderDate = findViewById(R.id.reminder_date)
        reminderTime = findViewById(R.id.reminder_time)
        reminderRepeat = findViewById(R.id.reminder_repeat)

        // Ambil data dari intent yang dikirim dari FormActivity
        val title = intent.getStringExtra("TITLE")
        val date = intent.getStringExtra("DATE")
        val time = intent.getStringExtra("TIME")
        val repeat = intent.getStringExtra("REPEAT")

        // Set data yang diterima ke TextView
        reminderTitle.text = title ?: "No Title"
        reminderDate.text = date ?: "No Date"
        reminderTime.text = time ?: "No Time"
        reminderRepeat.text = repeat ?: "No Repeat"
    }
}
