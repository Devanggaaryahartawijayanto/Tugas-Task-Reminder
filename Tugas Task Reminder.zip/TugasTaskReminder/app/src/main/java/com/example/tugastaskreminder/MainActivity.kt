package com.example.tugastaskreminder


import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Temukan tombol Add Task berdasarkan ID
        val addTaskButton: Button = findViewById(R.id.btn_add_task)

        // Set onClickListener untuk tombol Add Task
        addTaskButton.setOnClickListener {
            // Intent untuk berpindah dari MainActivity ke FormActivity
            val intent = Intent(this, FormActivity::class.java)
            startActivity(intent)
        }
    }
}