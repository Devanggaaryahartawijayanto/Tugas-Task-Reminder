package com.example.tugastaskreminder

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.content.Intent
import com.example.tugastaskreminder.R
import java.util.Calendar

class FormActivity : AppCompatActivity() {

    private lateinit var btnSelectDate: Button
    private lateinit var btnSelectTime: Button
    private lateinit var btnAddTask: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form)

        btnSelectDate = findViewById(R.id.btn_select_date)
        btnSelectTime = findViewById(R.id.btn_select_time)
        btnAddTask = findViewById(R.id.btn_add_task)

        // Pop up tanggal
        btnSelectDate.setOnClickListener {
            showDatePicker()
        }

        // Pop up Waktu
        btnSelectTime.setOnClickListener {
            showTimePicker()
        }

        // Pop up Konfirmasi dan diteruskan ke ReminderActivity
        btnAddTask.setOnClickListener {
            showConfirmationDialog()
        }
    }

    // Fungsi memunculkan DatePicker
    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val dateString = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                btnSelectDate.text = dateString // Display the selected date on the button
            },
            year, month, day
        )
        datePickerDialog.show()
    }

    // Fungsi memunculkan TimePicker
    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            this,
            { _, selectedHour, selectedMinute ->
                val timeString = String.format("%02d:%02d", selectedHour, selectedMinute)
                btnSelectTime.text = timeString // Display the selected time on the button
            },
            hour, minute, true
        )
        timePickerDialog.show()
    }

    // Fungsi Untuk Memunculkan Konfirmasi Dialog dan Mengirim Data ke ReminderActiviry
    private fun showConfirmationDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("SimpliRemind")
        builder.setMessage("Do you want to add this as a new task?")

        // Tombol Konfirmasi Ya (Memindah ke halaman ReminderActivity)
        builder.setPositiveButton("Yes") { dialog, _ ->
            // Mengambil input dari form
            val title = findViewById<EditText>(R.id.input_title).text.toString()
            val date = btnSelectDate.text.toString()
            val time = btnSelectTime.text.toString()
            val repeat = findViewById<Spinner>(R.id.spinner_repeat).selectedItem.toString()

            // Intent untuk berpindah ke ReminderActivity
            val intent = Intent(this, ReminderActivity::class.java)

            // Mengirim data melalui Intent
            intent.putExtra("TITLE", title)
            intent.putExtra("DATE", date)
            intent.putExtra("TIME", time)
            intent.putExtra("REPEAT", repeat)

            // Mulai ReminderActivity
            startActivity(intent)
            dialog.dismiss()
        }

        // Tombol Konfirmasi Ya (Cuekin dialog)
        builder.setNegativeButton("No") { dialog, _ ->
            dialog.dismiss()
        }

        // Memunculkan dialog
        val alertDialog = builder.create()

        // Mengatur Warna Button
        alertDialog.setOnShowListener {
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(android.R.color.holo_blue_light))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(android.R.color.holo_red_light))
        }

        alertDialog.show()
    }
}
